defmodule SampleTest do
  use ExUnit.Case

  test "truth" do
    assert true
  end
end