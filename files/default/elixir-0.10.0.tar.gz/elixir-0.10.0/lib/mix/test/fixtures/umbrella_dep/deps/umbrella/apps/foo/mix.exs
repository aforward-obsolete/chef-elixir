defmodule Foo.Mix do
  use Mix.Project

  def project do
    [ app: :foo,
      version: "0.1.0" ]
  end
end
