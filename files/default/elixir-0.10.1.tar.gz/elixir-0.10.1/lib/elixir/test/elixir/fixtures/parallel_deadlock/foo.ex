defmodule Foo do
  Bar.__info__(:macros)
end