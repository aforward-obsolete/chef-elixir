defmodule Tuple do
  @moduledoc false
end