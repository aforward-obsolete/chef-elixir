defmodule Foo do
  def message, do: "message_from_foo"
end