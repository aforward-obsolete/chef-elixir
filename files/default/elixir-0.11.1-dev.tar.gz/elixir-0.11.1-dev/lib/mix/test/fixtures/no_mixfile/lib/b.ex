defmodule B do
  
end